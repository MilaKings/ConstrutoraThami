package com.construtora.construtorathami;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FaleConoscoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fale_conosco);

        Button botaoEnviarMensagem = (Button) findViewById(R.id.formulario_enviar_mensagem);
        botaoEnviarMensagem.setOnClickListener(new View.OnClickListener()  {
            @Override
            public void onClick (View v) {
                Toast.makeText(FaleConoscoActivity.this, "Mensagem enviada!", Toast.LENGTH_SHORT).show(); //se deixar só this, refencia a classe de dentro
                finish();
            }
        });
    }
}
