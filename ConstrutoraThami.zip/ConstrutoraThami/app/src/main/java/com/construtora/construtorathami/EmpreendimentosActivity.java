package com.construtora.construtorathami;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class EmpreendimentosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_empreendimentos);


        String[] listaEmpreendimentos = {"Jardim Nascente", "Forte de Santa Cruz", "Águas Claras"};
        ListView listaTelaEmpreendimentos = (ListView) findViewById(R.id.lista_tela_empreendimentos); //casting no (ListView)
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listaEmpreendimentos); //converte o array de string em View
        listaTelaEmpreendimentos.setAdapter(adapter);  //a lista de alunos vai utilizar o adapter como seu adapter para mostrar na tela


    }
}
