package com.construtora.construtorathami;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class TelaInicialActivity extends AppCompatActivity {
    List<String> opcoes;
    ArrayAdapter<String> adaptador;
    ListView listaTelaInicial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicial);
        listaTelaInicial = (ListView) findViewById(R.id.lista_tela_inicial);

        Button faleConosco = (Button) findViewById (R.id.fale_conosco);
        faleConosco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v)  {
                Intent intentVaiParaFaleConosco = new Intent (TelaInicialActivity.this, FaleConoscoActivity.class);
                startActivity(intentVaiParaFaleConosco);
            }
        });

        opcoes = new ArrayList<String>();

        opcoes.add("Sobre a Thami");
        opcoes.add("Empreendimentos");
        opcoes.add("Notícias");



        adaptador = new ArrayAdapter<String>(TelaInicialActivity.this, android.R.layout.simple_list_item_1, opcoes);
        listaTelaInicial.setAdapter(adaptador);
        listaTelaInicial.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0: telaSobre();
                        break;
                    case 1: telaEmpreendimentos();
                        break;
                    case 2: telaNoticias();
                        break;
                }
            }
        });
    }

    private void telaSobre() {
        Intent vaiParaSobre = new Intent(TelaInicialActivity.this, SobreActivity.class);
        startActivity(vaiParaSobre);
    }

    private void telaEmpreendimentos() {
        Intent vaiParaEmpreendimentos = new Intent(TelaInicialActivity.this, EmpreendimentosActivity.class);
        startActivity(vaiParaEmpreendimentos);
    }

    private void telaNoticias() {
        Intent vaiParaNoticias = new Intent(TelaInicialActivity.this, NoticiasActivity.class);
        startActivity(vaiParaNoticias);
    }

//
////        String[] listaInicial = {"Sobre a Thami", "Empreendimentos", "Notícias"};
////        ListView listaTelaInicial = (ListView) findViewById(R.id.lista_tela_inicial); //casting no (ListView)
////        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listaInicial); //converte o array de string em View
////        listaTelaInicial.setAdapter(adapter);  //a lista de alunos vai utilizar o adapter como seu adapter para mostrar na tela
//

//    }
}
